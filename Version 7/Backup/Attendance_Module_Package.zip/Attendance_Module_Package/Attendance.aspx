<%@ Page Title="Attendance" Language="C#" MasterPageFile="~/Site.Master"
    AutoEventWireup="true" CodeFile="Attendance.aspx.cs"
    Inherits="PayrollWebApp.AttendancePage" %>

<asp:Content ID="c1" ContentPlaceHolderID="PageTitleSlot" runat="server">
    Attendance
</asp:Content>

<asp:Content ID="c2" ContentPlaceHolderID="PageBodySlot" runat="server">

<h1>Attendance</h1>
<asp:Label runat="server" ID="lblMsg" />

<div class="card">
    <h2>Import Attendance from Excel</h2>

    <div class="formgrid">
        <div class="field">
            <label>Attendance Excel File (.xlsx)</label>
            <asp:FileUpload runat="server" ID="fuAttendance" />
        </div>

        <div class="field">
            <label>Official OUT Time *</label>
            <asp:TextBox runat="server" ID="txtOfficialOutTime"
                TextMode="Time" />
        </div>
    </div>

    <p class="help">
        Reporting after 8:25 AM is Late unless approved permission exists.
        Approved permission is allowed up to 1.5 hours. More than 1.5 hours
        late arrival or early departure is treated as Half Day.
    </p>

    <asp:Button runat="server" ID="btnImport"
        Text="Import & Process Attendance"
        CssClass="btn"
        OnClick="btnImport_Click" />
</div>

<div class="card">
    <h2>Monthly Attendance Summary</h2>

    <div class="formgrid">
        <div class="field">
            <label>Month</label>
            <asp:TextBox runat="server" ID="txtMonth" TextMode="Month" />
        </div>

        <div class="field">
            <label>Branch</label>
            <asp:DropDownList runat="server" ID="ddlBranch" />
        </div>
    </div>

    <asp:Button runat="server" ID="btnLoad"
        Text="Load Summary"
        CssClass="btn"
        OnClick="btnLoad_Click" />

    <div class="tablewrap" style="margin-top:18px;">
        <asp:GridView runat="server" ID="gvSummary"
            AutoGenerateColumns="False" GridLines="None">
            <Columns>
                <asp:BoundField DataField="EmployeeCode" HeaderText="Code" />
                <asp:BoundField DataField="EmployeeName" HeaderText="Employee" />
                <asp:BoundField DataField="WorkingDays" HeaderText="Working Days" />
                <asp:BoundField DataField="PresentDays" HeaderText="Present" />
                <asp:BoundField DataField="PaidHolidays" HeaderText="Paid Holidays" />
                <asp:BoundField DataField="CasualLeaveDays" HeaderText="CL" DataFormatString="{0:0.##}" />
                <asp:BoundField DataField="LateCount" HeaderText="Lates" />
                <asp:BoundField DataField="PermissionCount" HeaderText="Permissions" />
                <asp:BoundField DataField="HalfDayUnits" HeaderText="Half Days" DataFormatString="{0:0.##}" />
                <asp:BoundField DataField="AbsentDays" HeaderText="Absent" DataFormatString="{0:0.##}" />
                <asp:BoundField DataField="LeaveEquivalent" HeaderText="Leave Eq." DataFormatString="{0:0.##}" />
                <asp:BoundField DataField="FreeAllowance" HeaderText="Free" DataFormatString="{0:0.##}" />
                <asp:BoundField DataField="DeductionDays" HeaderText="Salary Deduction Days" DataFormatString="{0:0.##}" />
            </Columns>
        </asp:GridView>
    </div>
</div>

<div class="card">
    <h2>Attendance Rules</h2>
    <ul>
        <li>After 8:25 AM = Late, unless approved permission exists.</li>
        <li>1 day equivalent per month is free and does not carry forward.</li>
        <li>Every 3 Lates = 1 day equivalent.</li>
        <li>Every 2 Permissions = 0.5 day equivalent.</li>
        <li>Permission may cover approved late arrival / early departure up to 1.5 hours.</li>
        <li>More than 1.5 hours late / early = Half Day.</li>
        <li>2 Half Days = 1 full-day equivalent.</li>
        <li>No IN + No OUT + no approved leave = Absent = 1 full salary deduction day.</li>
        <li>Sundays and declared holidays are paid holidays.</li>
        <li>Saturday is a normal working day unless declared holiday.</li>
    </ul>
</div>

</asp:Content>
