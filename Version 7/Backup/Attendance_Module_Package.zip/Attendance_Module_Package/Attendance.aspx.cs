using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml.Linq;

namespace PayrollWebApp
{
    public partial class AttendancePage : Page
    {
        private static readonly TimeSpan LateThreshold = new TimeSpan(8, 25, 0);
        private const int PermissionMinutes = 90;

        protected void Page_Load(object sender, EventArgs e)
        {
            Auth.RequirePermission("AttendanceView");
            btnImport.Visible = Auth.HasPermission("AttendanceImport");

            if (!IsPostBack)
            {
                txtMonth.Text = DateTime.Today.ToString("yyyy-MM");
                BindBranches();
            }
        }

        private void BindBranches()
        {
            DataTable dt = Db.Query(
                @"SELECT BranchCode FROM Branches
                  WHERE IsActive=True ORDER BY BranchCode");

            ddlBranch.Items.Clear();
            ddlBranch.Items.Add(new ListItem("All Branches", ""));

            foreach (DataRow r in dt.Rows)
            {
                string code = Convert.ToString(r["BranchCode"]);
                ddlBranch.Items.Add(new ListItem(code, code));
            }
        }

        protected void btnImport_Click(object sender, EventArgs e)
        {
            Auth.RequirePermission("AttendanceImport");

            try
            {
                if (!fuAttendance.HasFile)
                    throw new InvalidOperationException("Please select the attendance Excel file.");

                string ext = Path.GetExtension(fuAttendance.FileName);
                if (!String.Equals(ext, ".xlsx", StringComparison.OrdinalIgnoreCase))
                    throw new InvalidOperationException("Please upload the provided .xlsx attendance template.");

                TimeSpan officialOut;
                if (!TimeSpan.TryParse(txtOfficialOutTime.Text, out officialOut))
                    throw new InvalidOperationException("Please enter the Official OUT Time before importing.");

                DataTable excel = ReadFirstWorksheet(fuAttendance.PostedFile.InputStream);
                int imported = ProcessRows(excel, officialOut);

                ShowSuccess(imported + " attendance row(s) imported and processed successfully.");

                if (excel.Rows.Count > 0 && excel.Columns.Contains("Date"))
                {
                    DateTime d;
                    if (TryDate(excel.Rows[0]["Date"], out d))
                        txtMonth.Text = d.ToString("yyyy-MM");
                }

                BindSummary();
            }
            catch (Exception ex)
            {
                ShowError(ex.Message);
            }
        }

        protected void btnLoad_Click(object sender, EventArgs e)
        {
            Auth.RequirePermission("AttendanceView");
            try { BindSummary(); }
            catch (Exception ex) { ShowError(ex.Message); }
        }

        private int ProcessRows(DataTable dt, TimeSpan officialOut)
        {
            RequireColumns(dt,
                "Employee ID", "Employee Name", "Date", "IN Time", "OUT Time",
                "Approved Permission", "Permission Type", "Approved Casual Leave",
                "Declared Holiday", "Remarks");

            int count = 0;
            foreach (DataRow row in dt.Rows)
            {
                string employeeCode = S(row["Employee ID"]);
                if (String.IsNullOrWhiteSpace(employeeCode)) continue;

                DateTime date;
                if (!TryDate(row["Date"], out date))
                    throw new InvalidOperationException("Invalid Date for Employee ID " + employeeCode + ".");

                object employeeIdObj = Db.Scalar(
                    "SELECT EmployeeID FROM Employees WHERE EmployeeCode=? AND IsActive=True",
                    P(employeeCode));

                if (employeeIdObj == null || employeeIdObj == DBNull.Value)
                    throw new InvalidOperationException("Employee ID not found or inactive: " + employeeCode);

                int employeeId = Convert.ToInt32(employeeIdObj);
                TimeSpan? inTime = ParseTime(row["IN Time"]);
                TimeSpan? outTime = ParseTime(row["OUT Time"]);
                bool approvedPermission = Yes(row["Approved Permission"]);
                string permissionType = S(row["Permission Type"]);
                bool approvedCL = Yes(row["Approved Casual Leave"]);
                bool declaredHoliday = Yes(row["Declared Holiday"]);
                string remarks = S(row["Remarks"]);

                DayResult r = CalculateDay(
                    date, inTime, outTime, officialOut,
                    approvedPermission, approvedCL, declaredHoliday);

                Db.Execute(
                    "DELETE FROM Attendance WHERE EmployeeID=? AND AttendanceDate=?",
                    P(employeeId), P(date.Date));

                Db.Execute(
                    @"INSERT INTO Attendance
                    (EmployeeID,AttendanceDate,InTime,OutTime,OfficialOutTime,
                     ApprovedPermission,PermissionType,ApprovedCasualLeave,DeclaredHoliday,
                     IsPaidHoliday,LateCount,PermissionCount,HalfDayUnits,CasualLeaveDays,
                     AbsentDays,AttendanceStatus,Remarks,ImportedOn)
                    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    P(employeeId), P(date.Date), PTime(inTime), PTime(outTime), P(officialOut),
                    P(approvedPermission), P(permissionType), P(approvedCL), P(declaredHoliday),
                    P(r.PaidHoliday), P(r.LateCount), P(r.PermissionCount), P(r.HalfDayUnits),
                    P(r.CasualLeaveDays), P(r.AbsentDays), P(r.Status), P(remarks), P(DateTime.Now));

                count++;
            }
            return count;
        }

        private DayResult CalculateDay(
            DateTime date, TimeSpan? inTime, TimeSpan? outTime, TimeSpan officialOut,
            bool approvedPermission, bool approvedCL, bool declaredHoliday)
        {
            DayResult r = new DayResult();

            if (date.DayOfWeek == DayOfWeek.Sunday || declaredHoliday)
            {
                r.PaidHoliday = true;
                r.Status = "Paid Holiday";
                return r;
            }

            if (approvedCL)
            {
                r.CasualLeaveDays = 1m;
                r.Status = "Casual Leave";
                return r;
            }

            if (!inTime.HasValue && !outTime.HasValue)
            {
                r.AbsentDays = 1m;
                r.Status = "Absent";
                return r;
            }

            int lateMinutes = 0;
            if (inTime.HasValue && inTime.Value > LateThreshold)
                lateMinutes = (int)Math.Ceiling((inTime.Value - LateThreshold).TotalMinutes);

            int earlyMinutes = 0;
            if (outTime.HasValue && outTime.Value < officialOut)
                earlyMinutes = (int)Math.Ceiling((officialOut - outTime.Value).TotalMinutes);

            List<string> parts = new List<string>();

            if (approvedPermission)
            {
                ApplyApprovedIrregularity(r, lateMinutes, "Late Permission", parts);
                ApplyApprovedIrregularity(r, earlyMinutes, "Early Permission", parts);
            }
            else
            {
                ApplyUnapprovedIrregularity(r, lateMinutes, "Late", parts);
                ApplyUnapprovedIrregularity(r, earlyMinutes, "Early Departure", parts);
            }

            if (parts.Count == 0)
                r.Status = "Present";
            else
                r.Status = String.Join(" + ", parts.ToArray());

            return r;
        }

        private static void ApplyApprovedIrregularity(
            DayResult r, int minutes, string label, List<string> parts)
        {
            if (minutes <= 0) return;

            if (minutes > PermissionMinutes)
            {
                r.HalfDayUnits += 0.5m;
                parts.Add("Half Day");
            }
            else
            {
                r.PermissionCount++;
                parts.Add(label);
            }
        }

        private static void ApplyUnapprovedIrregularity(
            DayResult r, int minutes, string label, List<string> parts)
        {
            if (minutes <= 0) return;

            if (minutes > PermissionMinutes)
            {
                r.HalfDayUnits += 0.5m;
                parts.Add("Half Day");
            }
            else
            {
                r.LateCount++;
                parts.Add(label);
            }
        }

        private void BindSummary()
        {
            DateTime month;
            if (!DateTime.TryParse(txtMonth.Text + "-01", out month))
                throw new InvalidOperationException("Please select a valid month.");

            DateTime next = month.AddMonths(1);
            string branch = ddlBranch.SelectedValue;

            DataTable src = Db.Query(
                @"SELECT E.EmployeeCode,E.EmployeeName,E.BranchCode,
                         A.AttendanceDate,A.IsPaidHoliday,A.LateCount,A.PermissionCount,
                         A.HalfDayUnits,A.CasualLeaveDays,A.AbsentDays,A.AttendanceStatus
                  FROM Attendance A
                  INNER JOIN Employees E ON E.EmployeeID=A.EmployeeID
                  WHERE A.AttendanceDate>=? AND A.AttendanceDate<?
                    AND (?='' OR E.BranchCode=?)
                  ORDER BY E.EmployeeName,A.AttendanceDate",
                P(month.Date), P(next.Date), P(branch), P(branch));

            DataTable result = CreateSummaryTable();
            Dictionary<string, Summary> map = new Dictionary<string, Summary>(StringComparer.OrdinalIgnoreCase);

            foreach (DataRow row in src.Rows)
            {
                string code = S(row["EmployeeCode"]);
                Summary s;
                if (!map.TryGetValue(code, out s))
                {
                    s = new Summary();
                    s.EmployeeCode = code;
                    s.EmployeeName = S(row["EmployeeName"]);
                    map[code] = s;
                }

                bool paidHoliday = Convert.ToBoolean(row["IsPaidHoliday"]);
                if (paidHoliday) s.PaidHolidays++;
                else s.WorkingDays++;

                string status = S(row["AttendanceStatus"]);
                if (!paidHoliday && status == "Present") s.PresentDays++;

                s.CasualLeaveDays += D(row["CasualLeaveDays"]);
                s.LateCount += Convert.ToInt32(row["LateCount"]);
                s.PermissionCount += Convert.ToInt32(row["PermissionCount"]);
                s.HalfDayUnits += D(row["HalfDayUnits"]);
                s.AbsentDays += D(row["AbsentDays"]);
            }

            foreach (Summary s in map.Values)
            {
                decimal lateEquivalent = (s.LateCount / 3) * 1m;
                decimal permissionEquivalent = (s.PermissionCount / 2) * 0.5m;
                decimal leaveEquivalent = s.CasualLeaveDays + lateEquivalent + permissionEquivalent + s.HalfDayUnits;
                decimal free = Math.Min(1m, leaveEquivalent);
                decimal deduction = Math.Max(0m, leaveEquivalent - 1m) + s.AbsentDays;

                result.Rows.Add(
                    s.EmployeeCode, s.EmployeeName, s.WorkingDays, s.PresentDays,
                    s.PaidHolidays, s.CasualLeaveDays, s.LateCount, s.PermissionCount,
                    s.HalfDayUnits, s.AbsentDays, leaveEquivalent, free, deduction);
            }

            gvSummary.DataSource = result;
            gvSummary.DataBind();
        }

        private static DataTable CreateSummaryTable()
        {
            DataTable t = new DataTable();
            t.Columns.Add("EmployeeCode", typeof(string));
            t.Columns.Add("EmployeeName", typeof(string));
            t.Columns.Add("WorkingDays", typeof(int));
            t.Columns.Add("PresentDays", typeof(int));
            t.Columns.Add("PaidHolidays", typeof(int));
            t.Columns.Add("CasualLeaveDays", typeof(decimal));
            t.Columns.Add("LateCount", typeof(int));
            t.Columns.Add("PermissionCount", typeof(int));
            t.Columns.Add("HalfDayUnits", typeof(decimal));
            t.Columns.Add("AbsentDays", typeof(decimal));
            t.Columns.Add("LeaveEquivalent", typeof(decimal));
            t.Columns.Add("FreeAllowance", typeof(decimal));
            t.Columns.Add("DeductionDays", typeof(decimal));
            return t;
        }

        private static DataTable ReadFirstWorksheet(Stream input)
        {
            MemoryStream ms = new MemoryStream();
            input.CopyTo(ms);
            ms.Position = 0;

            using (ZipArchive zip = new ZipArchive(ms, ZipArchiveMode.Read, true))
            {
                List<string> shared = ReadSharedStrings(zip);
                string sheetPath = GetFirstSheetPath(zip);
                ZipArchiveEntry sheetEntry = zip.GetEntry(sheetPath);
                if (sheetEntry == null) throw new InvalidOperationException("Excel worksheet could not be read.");

                XDocument doc;
                using (Stream s = sheetEntry.Open()) doc = XDocument.Load(s);
                XNamespace ns = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";

                List<List<string>> rows = new List<List<string>>();
                int maxCols = 0;
                foreach (XElement row in doc.Descendants(ns + "row"))
                {
                    Dictionary<int, string> cells = new Dictionary<int, string>();
                    foreach (XElement c in row.Elements(ns + "c"))
                    {
                        string reference = (string)c.Attribute("r") ?? "A1";
                        int index = ColumnIndex(reference);
                        string type = (string)c.Attribute("t") ?? "";
                        string value = "";

                        if (type == "inlineStr")
                            value = String.Concat(c.Descendants(ns + "t")).Trim();
                        else
                        {
                            XElement v = c.Element(ns + "v");
                            value = v == null ? "" : v.Value;
                            if (type == "s")
                            {
                                int si;
                                if (Int32.TryParse(value, out si) && si >= 0 && si < shared.Count)
                                    value = shared[si];
                            }
                        }
                        cells[index] = value;
                        if (index + 1 > maxCols) maxCols = index + 1;
                    }

                    List<string> values = new List<string>();
                    for (int i = 0; i < maxCols; i++)
                    {
                        string v;
                        values.Add(cells.TryGetValue(i, out v) ? v : "");
                    }
                    rows.Add(values);
                }

                if (rows.Count == 0) throw new InvalidOperationException("Excel file is empty.");

                DataTable t = new DataTable();
                foreach (string h in rows[0])
                {
                    string name = h.Trim();
                    if (String.IsNullOrEmpty(name)) name = "Column" + (t.Columns.Count + 1);
                    t.Columns.Add(name, typeof(string));
                }

                for (int r = 1; r < rows.Count; r++)
                {
                    bool any = false;
                    object[] vals = new object[t.Columns.Count];
                    for (int c = 0; c < t.Columns.Count; c++)
                    {
                        string value = c < rows[r].Count ? rows[r][c] : "";
                        vals[c] = value;
                        if (!String.IsNullOrWhiteSpace(value)) any = true;
                    }
                    if (any) t.Rows.Add(vals);
                }
                return t;
            }
        }

        private static List<string> ReadSharedStrings(ZipArchive zip)
        {
            List<string> list = new List<string>();
            ZipArchiveEntry e = zip.GetEntry("xl/sharedStrings.xml");
            if (e == null) return list;
            XDocument doc;
            using (Stream s = e.Open()) doc = XDocument.Load(s);
            XNamespace ns = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
            foreach (XElement si in doc.Descendants(ns + "si"))
                list.Add(String.Concat(si.Descendants(ns + "t")));
            return list;
        }

        private static string GetFirstSheetPath(ZipArchive zip)
        {
            ZipArchiveEntry workbook = zip.GetEntry("xl/workbook.xml");
            ZipArchiveEntry rels = zip.GetEntry("xl/_rels/workbook.xml.rels");
            if (workbook == null || rels == null) return "xl/worksheets/sheet1.xml";

            XDocument wb; using (Stream s = workbook.Open()) wb = XDocument.Load(s);
            XDocument rs; using (Stream s = rels.Open()) rs = XDocument.Load(s);
            XNamespace main = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
            XNamespace rel = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";
            XNamespace pkg = "http://schemas.openxmlformats.org/package/2006/relationships";

            XElement sheet = null;
            foreach (XElement x in wb.Descendants(main + "sheet")) { sheet = x; break; }
            if (sheet == null) return "xl/worksheets/sheet1.xml";
            string id = (string)sheet.Attribute(rel + "id");
            foreach (XElement r in rs.Descendants(pkg + "Relationship"))
            {
                if ((string)r.Attribute("Id") == id)
                {
                    string target = (string)r.Attribute("Target");
                    if (target.StartsWith("/")) return target.TrimStart('/');
                    return "xl/" + target.Replace("\\", "/");
                }
            }
            return "xl/worksheets/sheet1.xml";
        }

        private static int ColumnIndex(string cellReference)
        {
            int n = 0;
            foreach (char ch in cellReference)
            {
                if (!Char.IsLetter(ch)) break;
                n = n * 26 + (Char.ToUpperInvariant(ch) - 'A' + 1);
            }
            return Math.Max(0, n - 1);
        }

        private static void RequireColumns(DataTable t, params string[] names)
        {
            foreach (string name in names)
                if (!t.Columns.Contains(name))
                    throw new InvalidOperationException("Excel column missing: " + name);
        }

        private static bool TryDate(object value, out DateTime date)
        {
            string s = S(value);
            double serial;
            if (Double.TryParse(s, NumberStyles.Any, CultureInfo.InvariantCulture, out serial) && serial > 1000)
            {
                date = DateTime.FromOADate(serial);
                return true;
            }
            return DateTime.TryParse(s, CultureInfo.InvariantCulture, DateTimeStyles.None, out date)
                || DateTime.TryParse(s, out date);
        }

        private static TimeSpan? ParseTime(object value)
        {
            string s = S(value);
            if (String.IsNullOrWhiteSpace(s)) return null;
            TimeSpan ts;
            if (TimeSpan.TryParse(s, out ts)) return ts;
            DateTime d;
            if (DateTime.TryParse(s, out d)) return d.TimeOfDay;
            double serial;
            if (Double.TryParse(s, NumberStyles.Any, CultureInfo.InvariantCulture, out serial))
                return TimeSpan.FromDays(serial - Math.Floor(serial));
            throw new InvalidOperationException("Invalid time value: " + s);
        }

        private static bool Yes(object v)
        {
            string s = S(v);
            return s.Equals("yes", StringComparison.OrdinalIgnoreCase)
                || s.Equals("y", StringComparison.OrdinalIgnoreCase)
                || s.Equals("true", StringComparison.OrdinalIgnoreCase)
                || s == "1";
        }

        private static string S(object v) { return v == null || v == DBNull.Value ? "" : Convert.ToString(v).Trim(); }
        private static decimal D(object v) { return v == null || v == DBNull.Value ? 0m : Convert.ToDecimal(v); }
        private static OleDbParameter P(object v) { return new OleDbParameter("?", v ?? DBNull.Value); }
        private static OleDbParameter PTime(TimeSpan? v) { return P(v.HasValue ? (object)v.Value : DBNull.Value); }

        private void ShowError(string m) { lblMsg.CssClass = "message error"; lblMsg.Text = m; }
        private void ShowSuccess(string m) { lblMsg.CssClass = "message"; lblMsg.Text = m; }

        private class DayResult
        {
            public bool PaidHoliday;
            public int LateCount;
            public int PermissionCount;
            public decimal HalfDayUnits;
            public decimal CasualLeaveDays;
            public decimal AbsentDays;
            public string Status = "Present";
        }

        private class Summary
        {
            public string EmployeeCode;
            public string EmployeeName;
            public int WorkingDays;
            public int PresentDays;
            public int PaidHolidays;
            public decimal CasualLeaveDays;
            public int LateCount;
            public int PermissionCount;
            public decimal HalfDayUnits;
            public decimal AbsentDays;
        }
    }
}
