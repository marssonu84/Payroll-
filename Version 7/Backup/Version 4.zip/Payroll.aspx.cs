using System;
using System.Data;
using System.Data.OleDb;
using System.Web.UI.WebControls;

namespace PayrollWebApp
{
    public partial class PayrollPage : System.Web.UI.Page
    {
        protected void Page_Load(object s, EventArgs e)
        {
Auth.RequireAuth();

            if (!IsPostBack)
            {
                txtMonth.Text = DateTime.Today.ToString("yyyy-MM");

                var dt = Db.Query(
                    "SELECT BranchCode FROM Branches WHERE IsActive=True ORDER BY BranchCode"
                );

                ddlBranch.DataSource = dt;
                ddlBranch.DataTextField = "BranchCode";
                ddlBranch.DataValueField = "BranchCode";
                ddlBranch.DataBind();
            }
        }

        protected void btnLoad_Click(object s, EventArgs e)
        {
            BindPayroll(BuildTableFromEmployees());
        }

        protected void btnProcess_Click(object s, EventArgs e)
        {
            try
            {
                var month = DateTime.Parse(txtMonth.Text + "-01");

                int days = I(
                    txtDays.Text,
                    DateTime.DaysInMonth(month.Year, month.Month)
                );

                foreach (GridViewRow row in gvPayroll.Rows)
                {
                    int empId =
                        Convert.ToInt32(
                            gvPayroll.DataKeys[row.RowIndex].Value
                        );

                    var emp = Db.Query(
                        "SELECT * FROM Employees WHERE EmployeeID=?",
                        P(empId)
                    ).Rows[0];

                    decimal leaves =
                        M(((TextBox)row.FindControl("txtLeaves")).Text);

                    decimal adv =
                        M(((TextBox)row.FindControl("txtAdvance")).Text);

                    decimal other =
                        M(((TextBox)row.FindControl("txtOther")).Text);

                    var r = PayrollCalculator.Calculate(
                        V(emp["StandardSalaryPrev"]),
                        V(emp["IncrementAmount"]),
                        V(emp["SalaryAdjustment"]),
                        days,
                        leaves,
                        B(emp["PFMember"]),
                        B(emp["ESIMember"]),
                        adv,
                        other
                    );

                    Db.Execute(
                        "DELETE FROM Payroll WHERE EmployeeID=? AND SalaryMonth=?",
                        P(empId),
                        P(month)
                    );

                    Db.Execute(
                        @"INSERT INTO Payroll
                        (
                            EmployeeID,
                            SalaryMonth,
                            DaysInMonth,
                            Leaves,
                            StandardSalary,
                            LOP,
                            GrossSalary,
                            Basic,
                            HRA,
                            OvertimeAllowance,
                            PF,
                            ESI,
                            PT,
                            SalaryAdvance,
                            OtherDeductions,
                            TotalDeductions,
                            NetPay,
                            CreatedOn
                        )
                        VALUES
                        (
                            ?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?
                        )",
                        P(empId),
                        P(month),
                        P(days),
                        P(leaves),
                        P(r.StandardSalary),
                        P(r.Lop),
                        P(r.Gross),
                        P(r.Basic),
                        P(r.Hra),
                        P(r.OvertimeAllowance),
                        P(r.Pf),
                        P(r.Esi),
                        P(r.Pt),
                        P(adv),
                        P(other),
                        P(r.TotalDeductions),
                        P(r.NetPay),
                        P(DateTime.Now)
                    );
                }

                lblMsg.CssClass = "message";

                lblMsg.Text =
                    "Payroll calculated and saved for " +
                    month.ToString("MMMM yyyy") +
                    ".";

                BindPayroll(
                    BuildTableFromDatabase(month)
                );
            }
            catch (Exception ex)
            {
                lblMsg.CssClass = "message error";
                lblMsg.Text = ex.Message;
            }
        }

        private DataTable BuildTableFromEmployees()
        {
            var src = Db.Query(
                @"SELECT
                    EmployeeID,
                    EmployeeName,
                    Designation,
                    StandardSalaryPrev,
                    IncrementAmount,
                    SalaryAdjustment,
                    PFMember,
                    ESIMember
                  FROM Employees
                  WHERE IsActive=True
                  AND BranchCode=?
                  ORDER BY EmployeeName",
                P(ddlBranch.SelectedValue)
            );

            return Build(src, null);
        }

        private DataTable BuildTableFromDatabase(DateTime month)
        {
            var src = Db.Query(
                @"SELECT
                    E.EmployeeID,
                    E.EmployeeName,
                    E.Designation,
                    E.StandardSalaryPrev,
                    E.IncrementAmount,
                    E.SalaryAdjustment,
                    P.Leaves,
                    P.LOP,
                    P.GrossSalary,
                    P.Basic,
                    P.HRA,
                    P.OvertimeAllowance,
                    P.PF,
                    P.ESI,
                    P.PT,
                    P.SalaryAdvance,
                    P.OtherDeductions,
                    P.TotalDeductions,
                    P.NetPay
                  FROM Employees E
                  INNER JOIN Payroll P
                    ON E.EmployeeID=P.EmployeeID
                  WHERE E.BranchCode=?
                  AND P.SalaryMonth=?
                  ORDER BY E.EmployeeName",
                P(ddlBranch.SelectedValue),
                P(month)
            );

            return Build(src, month);
        }

        private DataTable Build(DataTable src, DateTime? saved)
        {
            var dt = new DataTable();

            foreach (
                string c in new[]
                {
                    "EmployeeID",
                    "EmployeeName",
                    "Designation",
                    "StandardSalary",
                    "Leaves",
                    "LOP",
                    "GrossSalary",
                    "Basic",
                    "HRA",
                    "OvertimeAllowance",
                    "PF",
                    "ESI",
                    "PT",
                    "SalaryAdvance",
                    "OtherDeductions",
                    "TotalDeductions",
                    "NetPay"
                }
            )
            {
                dt.Columns.Add(
                    c,
                    c == "EmployeeName" || c == "Designation"
                        ? typeof(string)
                        : c == "EmployeeID"
                            ? typeof(int)
                            : typeof(decimal)
                );
            }

            int days = I(
                txtDays.Text,
                DateTime.DaysInMonth(
                    DateTime.Parse(txtMonth.Text + "-01").Year,
                    DateTime.Parse(txtMonth.Text + "-01").Month
                )
            );

            foreach (DataRow e in src.Rows)
            {
                var n = dt.NewRow();

                n["EmployeeID"] =
                    Convert.ToInt32(e["EmployeeID"]);

                n["EmployeeName"] =
                    e["EmployeeName"];

                n["Designation"] =
                    e["Designation"];

                decimal leaves =
                    saved.HasValue
                        ? V(e["Leaves"])
                        : 0;

                decimal adv =
                    saved.HasValue
                        ? V(e["SalaryAdvance"])
                        : 0;

                decimal other =
                    saved.HasValue
                        ? V(e["OtherDeductions"])
                        : 0;

                bool pfMember =
                    saved.HasValue
                        ? false
                        : B(e["PFMember"]);

                bool esiMember =
                    saved.HasValue
                        ? false
                        : B(e["ESIMember"]);

                var r =
                    PayrollCalculator.Calculate(
                        V(e["StandardSalaryPrev"]),
                        V(e["IncrementAmount"]),
                        V(e["SalaryAdjustment"]),
                        days,
                        leaves,
                        pfMember,
                        esiMember,
                        adv,
                        other
                    );

                if (saved.HasValue)
                {
                    foreach (
                        string c in new[]
                        {
                            "LOP",
                            "GrossSalary",
                            "Basic",
                            "HRA",
                            "OvertimeAllowance",
                            "PF",
                            "ESI",
                            "PT",
                            "TotalDeductions",
                            "NetPay"
                        }
                    )
                    {
                        n[c] = V(e[c]);
                    }
                }
                else
                {
                    n["LOP"] =
                        r.Lop;

                    n["GrossSalary"] =
                        r.Gross;

                    n["Basic"] =
                        r.Basic;

                    n["HRA"] =
                        r.Hra;

                    n["OvertimeAllowance"] =
                        r.OvertimeAllowance;

                    n["PF"] =
                        r.Pf;

                    n["ESI"] =
                        r.Esi;

                    n["PT"] =
                        r.Pt;

                    n["TotalDeductions"] =
                        r.TotalDeductions;

                    n["NetPay"] =
                        r.NetPay;
                }

                n["StandardSalary"] =
                    V(e["StandardSalaryPrev"]) +
                    V(e["IncrementAmount"]) +
                    V(e["SalaryAdjustment"]);

                n["Leaves"] =
                    leaves;

                n["SalaryAdvance"] =
                    adv;

                n["OtherDeductions"] =
                    other;

                dt.Rows.Add(n);
            }

            return dt;
        }

        private void BindPayroll(DataTable dt)
        {
            gvPayroll.DataSource = dt;
            gvPayroll.DataBind();
        }

        private OleDbParameter P(object v)
        {
            return new OleDbParameter(
                "?",
                v ?? DBNull.Value
            );
        }

        private decimal M(string s)
        {
            decimal x;

            return decimal.TryParse(
                s,
                out x
            )
                ? x
                : 0;
        }

        private int I(string s, int d)
        {
            int x;

            return int.TryParse(
                s,
                out x
            )
                ? x
                : d;
        }

        private decimal V(object o)
        {
            return o == DBNull.Value
                ? 0
                : Convert.ToDecimal(o);
        }

        private bool B(object o)
        {
            return
                o != DBNull.Value &&
                Convert.ToBoolean(o);
        }
    }
}

