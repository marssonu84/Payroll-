using System;
using System.Security.Cryptography;
using System.Text;
using System.Web;

namespace PayrollWebApp
{
    public static class Auth
    {
        private const int SaltSize = 16;
        private const int HashSize = 32;
        private const int Iterations = 210000;

        public static string HashPassword(string password)
        {
            byte[] salt = new byte[SaltSize];

            using (RandomNumberGenerator rng =
                RandomNumberGenerator.Create())
            {
                rng.GetBytes(salt);
            }

            byte[] hash;

            using (var pbkdf2 =
                new Rfc2898DeriveBytes(
                    password,
                    salt,
                    Iterations,
                    HashAlgorithmName.SHA256))
            {
                hash = pbkdf2.GetBytes(HashSize);
            }

            return
                "PBKDF2$" +
                Iterations.ToString() +
                "$" +
                Convert.ToBase64String(salt) +
                "$" +
                Convert.ToBase64String(hash);
        }

        public static bool VerifyPassword(
            string password,
            string storedHash)
        {
            if (String.IsNullOrWhiteSpace(storedHash))
            {
                return false;
            }

            // New PBKDF2 format
            if (storedHash.StartsWith(
                "PBKDF2$",
                StringComparison.Ordinal))
            {
                string[] parts =
                    storedHash.Split('$');

                if (parts.Length != 4)
                {
                    return false;
                }

                int iterations;

                if (!Int32.TryParse(
                    parts[1],
                    out iterations))
                {
                    return false;
                }

                byte[] salt;
                byte[] expectedHash;

                try
                {
                    salt =
                        Convert.FromBase64String(
                            parts[2]);

                    expectedHash =
                        Convert.FromBase64String(
                            parts[3]);
                }
                catch
                {
                    return false;
                }

                byte[] actualHash;

                using (var pbkdf2 =
                    new Rfc2898DeriveBytes(
                        password,
                        salt,
                        iterations,
                        HashAlgorithmName.SHA256))
                {
                    actualHash =
                        pbkdf2.GetBytes(
                            expectedHash.Length);
                }

                return FixedTimeEquals(
                    actualHash,
                    expectedHash);
            }

            /*
             * Legacy SHA-256 support.
             * This allows the existing password
             * to work once during migration.
             */
            string legacyHash =
                LegacyHashPassword(password);

            return FixedTimeEquals(
                Encoding.UTF8.GetBytes(legacyHash),
                Encoding.UTF8.GetBytes(storedHash)
            );
        }

        public static bool NeedsPasswordUpgrade(
            string storedHash)
        {
            return
                String.IsNullOrWhiteSpace(storedHash) ||
                !storedHash.StartsWith(
                    "PBKDF2$",
                    StringComparison.Ordinal);
        }

        private static string LegacyHashPassword(
            string password)
        {
            using (SHA256 sha256 =
                SHA256.Create())
            {
                byte[] bytes =
                    sha256.ComputeHash(
                        Encoding.UTF8.GetBytes(password)
                    );

                return Convert.ToBase64String(bytes);
            }
        }

        private static bool FixedTimeEquals(
            byte[] a,
            byte[] b)
        {
            if (a == null ||
                b == null ||
                a.Length != b.Length)
            {
                return false;
            }

            int difference = 0;

            for (int i = 0; i < a.Length; i++)
            {
                difference |=
                    a[i] ^ b[i];
            }

            return difference == 0;
        }

        public static bool IsLoggedIn()
        {
            return
                HttpContext.Current != null &&
                HttpContext.Current.Session != null &&
                HttpContext.Current.Session["UserID"] != null;
        }

        public static void RequireAuth()
        {
            if (!IsLoggedIn())
            {
                HttpContext.Current.Response.Redirect(
                    "~/Login.aspx",
                    true
                );
            }
        }
    }
}
