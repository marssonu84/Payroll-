
using System;

using System.Data;

using System.Data.OleDb;

namespace PayrollWebApp
{

    public partial class Dashboard : System.Web.UI.Page
    {
        
        protected void Page_Load(object sender, EventArgs e)
        {

Auth.RequireAuth();

            if (IsPostBack) return;
            try
            {
                lblEmployees.Text = Convert.ToString(Db.Scalar("SELECT COUNT(*) FROM Employees WHERE IsActive=True"));
                var month = new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1);
                var dt = Db.Query(@"SELECT E.BranchCode, Count(P.PayrollID) AS Employees, Sum(P.GrossSalary) AS GrossSalary, Sum(P.PF) AS PF, Sum(P.ESI) AS ESI, Sum(P.PT) AS PT, Sum(P.SalaryAdvance) AS SalaryAdvance, Sum(P.TotalDeductions) AS TotalDeductions, Sum(P.NetPay) AS NetPay FROM Employees E INNER JOIN Payroll P ON E.EmployeeID=P.EmployeeID WHERE P.SalaryMonth=? GROUP BY E.BranchCode ORDER BY E.BranchCode", new System.Data.OleDb.OleDbParameter("?", month));
                gvSummary.DataSource = dt; gvSummary.DataBind();
                decimal g=0,d=0,n=0; foreach(DataRow r in dt.Rows){g+=Val(r["GrossSalary"]);d+=Val(r["TotalDeductions"]);n+=Val(r["NetPay"]);}
                lblGross.Text=g.ToString("N0");lblDeductions.Text=d.ToString("N0");lblNet.Text=n.ToString("N0");
            }
            catch(Exception ex){pnlError.Visible=true;lblError.Text="Database not ready. Open Setup.aspx first. " + ex.Message;}
        }
        private decimal Val(object o){return o==DBNull.Value?0:Convert.ToDecimal(o);}
    }
}






