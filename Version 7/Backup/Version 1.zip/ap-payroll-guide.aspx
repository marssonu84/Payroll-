

<!DOCTYPE HTML>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Andhra Pradesh Payroll Compliance & Tax Slabs Guide</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    <style>
        body { background-color: #f8f9fa; }
        .content-container { max-width: 800px; margin: 40px auto; background: #ffffff; padding: 30px; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
        footer { margin-top: 40px; padding: 20px; text-align: center; border-top: 1px solid #ddd; }
    </style>
</head>
<body>

<div class="container content-container">
    <h1 class="mb-4">Andhra Pradesh Payroll & Tax Compliance Guide</h1>
    <p class="text-muted">Comprehensive guide on statutory deductions, Professional Tax, and labor regulations in Andhra Pradesh.</p>
    <hr />

    <h2>1. Andhra Pradesh Professional Tax (PT) Slabs</h2>
    <p>In Andhra Pradesh, Professional Tax is levied under state regulations based on monthly wages:</p>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Gross Monthly Salary</th>
                <th>Monthly PT Payable</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>Up to ₹15,000</td>
                <td>Nil</td>
            </tr>
            <tr>
                <td>₹15,001 to ₹20,000</td>
                <td>₹150 / month</td>
            </tr>
            <tr>
                <td>₹20,001 and above</td>
                <td>₹200 / month</td>
            </tr>
        </tbody>
    </table>

    <h2 class="mt-4">2. Statutory Deductions Overview</h2>
    <ul>
        <li><strong>Provident Fund (EPF):</strong> 12% of Basic + DA, capped at ₹15,000 monthly threshold.</li>
        <li><strong>ESIC Insurance:</strong> 0.75% (Employee) and 3.25% (Employer) for salaries up to ₹21,000/month.</li>
        <li><strong>Loss of Pay (LOP):</strong> Deducted on a pro-rata basis according to calendar days worked.</li>
    </ul>

    <h2 class="mt-4">3. AP Shops & Establishments Act Guidelines</h2>
    <p>Under Andhra Pradesh labor laws:</p>
    <ul>
        <li><strong>Leave Entitlements:</strong> 12 days Casual Leave, 12 days Sick Leave, and 15 Earned Leaves after qualifying continuous service.</li>
        <li><strong>Overtime Wages:</strong> Work beyond standard weekly limits must be compensated at double (2x) the regular wage rate.</li>
    </ul>

    <hr class="my-4" />
    <a href="default.aspx" class="btn btn-primary">&larr; Back to Salary Calculator</a>
</div>

<footer>
    <p>&copy; 2026 Payroll Manager. All rights reserved.</p>
</footer>

</body>
</html>

