<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Privacy Policy - Payroll Manager</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    <style>
        body { background-color: #f8f9fa; }
        .content-container { max-width: 800px; margin: 40px auto; background: #ffffff; padding: 30px; border-radius: 8px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }
        footer { margin-top: 40px; padding: 20px; text-align: center; border-top: 1px solid #ddd; }
    </style>
</head>
<body>

<div class="container content-container">
    <h1 class="mb-4">Privacy Policy</h1>
    <p class="text-muted"><strong>Last Updated: July 21, 2026</strong></p>
    <hr />

    <p>At Payroll Manager, we are committed to protecting your privacy. This Privacy Policy explains how your information is handled when you use our payroll calculation tools.</p>

    <h3>1. Data Collection and Usage</h3>
    <ul>
        <li><strong>Calculations:</strong> Our salary calculator operates entirely on your device (client-side). When you enter data such as names, departments, or salary figures, this information <strong>is not sent to our servers</strong>, stored, or shared with third parties. All calculations occur within your browser's memory and are cleared when you refresh or leave the page.</li>
        <li><strong>Cookies:</strong> We use cookies to improve your user experience and for third-party services like Google AdSense to show relevant advertisements.</li>
        <li><strong>Analytics:</strong> We use Google Analytics to understand how visitors interact with our website to improve our services. This may include data such as your IP address, browser type, and pages visited.</li>
    </ul>

    <h3>2. Advertising (Google AdSense)</h3>
    <p>We use Google AdSense to display advertisements. Google uses cookies to serve ads based on your visit to this site and other websites on the Internet.</p>
    <p>You can opt out of personalized advertising by visiting <a href="https://adssettings.google.com/" target="_blank" rel="noopener">Google’s Ad Settings</a>.</p>

    <h3>3. Third-Party Links</h3>
    <p>Our website may contain links to external sites. We are not responsible for the privacy practices or the content of those websites.</p>

    <h3>4. Changes to This Policy</h3>
    <p>We may update this Privacy Policy from time to time. We will notify you of any changes by posting the new policy on this page.</p>

    <h3>5. Contact Us</h3>
    <p>If you have any questions about this Privacy Policy, please contact us at:</p>
    <p><code>marssonujobs@gmail.com</code></p>

   
</div>

</body>
</html>



