<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Professional Payroll Calculator & Employee Management Tool</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    <style>
        body { background-color: #f8f9fa; }
        .content-section { margin-top: 30px; background: white; padding: 20px; border-radius: 8px; }
        footer { margin-top: 40px; padding: 20px; text-align: center; border-top: 1px solid #ddd; }
    </style>
</head>
<body>

<div class="container mt-4">
    <!-- Header -->
    <header class="text-center mb-5">
        <h1>Payroll Management System</h1>
        <p class="lead">Efficiently manage employee salaries and tax deductions.</p>
    </header>

    <!-- The Calculator Tool -->
    <div class="card shadow mb-4">
        <!-- ... [Your existing form code here] ... -->
    </div>

    <!-- Mandatory Content Section (Vital for AdSense) -->
    <section class="content-section shadow-sm">
        <h3>Understanding Payroll Deductions in India</h3>
        <p>Managing payroll involves complex calculations including Gross Salary, Professional Tax (PT), Provident Fund (PF), and Employees' State Insurance (ESI). Our tool helps HR professionals and small business owners streamline these calculations based on current labor standards.</p>
        <ul>
            <li><strong>PF Calculation:</strong> Calculated at 12% for salaries under ₹15,000.</li>
            <li><strong>Professional Tax:</strong> Varies by state; our tool calculates based on standard slabs.</li>
            <li><strong>Leave Management:</strong> Automatic LOP (Loss of Pay) adjustment to ensure accurate net salary.</li>
        </ul>
    </section>

  
</div>

<p><h2><a href="ap-payroll-guide.aspx">AP Payroll & Tax Guide</a></p></h2>


    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Employee Salary Register (INR)</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-8404356823010331" crossorigin="anonymous"></script>

<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-18281869240"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'AW-18281869240');
</script>

<!-- Event snippet for Submit lead form conversion page -->
<script>
  gtag('event', 'conversion', {'send_to': 'AW-18281869240/6NJnCLPh2tMcELjfvI1E'});
</script>



</head>
<body class="bg-light">
    <div class="container mt-4">
        <div class="card shadow">
            <div class="card-header bg-success text-white">
                <h3 class="mb-0">Employee Payroll Sheet</h3>
                <small id="currentTime" class="d-block mt-1"></small>
            </div>
<br>
            

                <div class="row g-3 mb-3">
                    <div class="col-md-2">
                        <select id="txtMonth" class="form-select">
                            <option value="">Month</option>
                            <option>January</option><option>February</option><option>March</option><option>April</option>
                            <option>May</option><option>June</option><option>July</option><option>August</option>
                            <option>September</option><option>October</option><option>November</option><option>December</option>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <select id="txtYear" class="form-select">
                            <option value="">Year</option>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <input id="txtDays" class="form-control" placeholder="Days" readonly />
                    </div>
                    <div class="col-md-2">
                        <input id="txtEmpName" class="form-control" placeholder="Employee Name" />
                    </div>
                    <div class="col-md-2">
                        <input id="txtDepartment" class="form-control" placeholder="Department" />
                    </div>
                    <div class="col-md-2">
                        <div class="input-group">
                            <span class="input-group-text">₹</span>
                            <input id="txtSalary" type="number" min="0" step="0.01" class="form-control" placeholder="Gross Salary" />
                        </div>
                    </div>
                    <div class="col-md-2">
                        <input id="txtLeaves" type="number" min="0" step="1" class="form-control" placeholder="Leaves" />
                    </div>
                    <div class="col-md-2">
                        <input id="txtLop" class="form-control" placeholder="LOP" readonly />
                    </div>
                    <div class="col-md-2">
                        <button id="btnAddEmployee" class="btn btn-success w-100">Insert Employee Row</button>
                    </div>
                </div>

                <div id="editInfo" class="alert alert-warning py-2 d-none">
                    Editing record ID: <strong id="editIdText"></strong>
                    <button id="btnCancelEdit" class="btn btn-sm btn-outline-dark ms-2">Cancel Edit</button>
                </div>

                <div class="my-3 text-center">
                    <div class="small text-muted mb-2">Advertisement</div>
                    <ins class="adsbygoogle"
                         style="display:block"
                         data-ad-client="ca-pub-8404356823010331"
                         data-ad-slot="1234567890"
                         data-ad-format="auto"
                         data-full-width-responsive="true"></ins>
                </div>

                <div id="msgBox" class="mb-3"></div>

                <div class="table-responsive">
                    <table class="table table-striped table-bordered align-middle">
                        <thead>
                            <tr>
                                <th>Employee ID</th>
                                <th>Days</th>
                                <th>Employee Name</th>
                                <th>Department</th>
                                <th>Gross Salary (₹)</th>
                                <th>Leaves</th>
                                <th>LOP (₹)</th>
                                <th>Basic Salary (₹)</th>
                                <th>PF (₹)</th>
                                <th>ESI (₹)</th>
                                <th>GWS (₹)</th>
                                <th>PT (₹)</th>
                                <th>Net Salary (₹)</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody id="employeeBody"></tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script>
        const defaultEmployees = [
            { id: 1001, month: "January", year: 2026, days: 31, name: "Amit Sharma", department: "Administration", salary: 45000.00, leaves: 2, lop: 2903.23 },
            { id: 1002, month: "February", year: 2026, days: 28, name: "Priya Patel", department: "Human Resources", salary: 62000.00, leaves: 1, lop: 2214.29 },
            { id: 1003, month: "March", year: 2026, days: 31, name: "Rajesh Kumar", department: "Finance & Accounts", salary: 75000.00, leaves: 3, lop: 7258.06 }
        ];

        const employeeBody = document.getElementById("employeeBody");
        const empName = document.getElementById("txtEmpName");
        const department = document.getElementById("txtDepartment");
        const salary = document.getElementById("txtSalary");
        const leaves = document.getElementById("txtLeaves");
        const lop = document.getElementById("txtLop");
        const addBtn = document.getElementById("btnAddEmployee");
        const currentTime = document.getElementById("currentTime");
        const msgBox = document.getElementById("msgBox");
        const monthSelect = document.getElementById("txtMonth");
        const yearSelect = document.getElementById("txtYear");
        const daysInput = document.getElementById("txtDays");
        const editInfo = document.getElementById("editInfo");
        const editIdText = document.getElementById("editIdText");
        const btnCancelEdit = document.getElementById("btnCancelEdit");

        const currencyFormatter = new Intl.NumberFormat("en-IN", {
            style: "currency",
            currency: "INR"
        });

        let messageTimer = null;
        let editingId = null;
        let employees = [...defaultEmployees];

        function escapeHTML(text) {
            return String(text)
                .replace(/&/g, "&amp;")
                .replace(/</g, "&lt;")
                .replace(/>/g, "&gt;")
                .replace(/\"/g, "&quot;")
                .replace(/'/g, "&#39;");
        }

        function formatINR(value) {
            return currencyFormatter.format(value);
        }

        function getDaysInMonth(month, year) {
            const monthIndex = [
                "January","February","March","April","May","June",
                "July","August","September","October","November","December"
            ].indexOf(month);
            if (monthIndex === -1 || !year) return "";
            return new Date(year, monthIndex + 1, 0).getDate();
        }

        function calculateLopAmount(grossSalary, daysInMonth, leaveDays) {
            if (!daysInMonth) return 0;
            return (grossSalary / daysInMonth) * leaveDays;
        }

        function calculateBasicSalary(grossSalary, lopAmount) {
            return grossSalary - lopAmount;
        }

        function calculatePfAmount(basicSalary) {
            return basicSalary >= 15000 ? 1800 : basicSalary * 0.12;
        }

        function calculateEsiAmount(basicSalary) {
            const esi = basicSalary * 0.0075;
            return esi >= 21000 ? 0 : esi;
        }

        function calculateGws(grossSalary, lopAmount, pfAmount, esiAmount) {
            return grossSalary - lopAmount - pfAmount - esiAmount;
        }

        function calculatePt(gws) {
            if (gws >= 15000 && gws <= 20000) return 150;
            if (gws >= 20001) return 200;
            return 0;
        }

        function showMessage(text, type) {
            clearTimeout(messageTimer);
            msgBox.innerHTML = `<div class="alert alert-${type} py-2 mb-0">${escapeHTML(text)}</div>`;
            messageTimer = setTimeout(() => {
                msgBox.innerHTML = "";
            }, 3000);
        }

        function renderTable() {
            if (!employees.length) {
                employeeBody.innerHTML = `<tr><td colspan="14" class="text-center text-muted">No employees found</td></tr>`;
                return;
            }

            employeeBody.innerHTML = employees.map(emp => {
                const basicSalary = calculateBasicSalary(emp.salary, emp.lop);
                const pfAmount = calculatePfAmount(basicSalary);
                const esiAmount = calculateEsiAmount(basicSalary);
                const gws = calculateGws(emp.salary, emp.lop, pfAmount, esiAmount);
                const pt = calculatePt(gws);
                const netSalary = gws - pt;

                return `
                <tr>
                    <td>${emp.id}</td>
                    <td>${emp.days}</td>
                    <td>${escapeHTML(emp.name)}</td>
                    <td>${escapeHTML(emp.department)}</td>
                    <td>${formatINR(emp.salary)}</td>
                    <td>${emp.leaves}</td>
                    <td>${formatINR(emp.lop)}</td>
                    <td>${formatINR(basicSalary)}</td>
                    <td>${formatINR(pfAmount)}</td>
                    <td>${formatINR(esiAmount)}</td>
                    <td>${formatINR(gws)}</td>
                    <td>${formatINR(pt)}</td>
                    <td>${formatINR(netSalary)}</td>
                    <td>
                        <button class="btn btn-sm btn-primary me-1" data-action="edit" data-id="${emp.id}">Edit</button>
                        <button class="btn btn-sm btn-danger" data-action="delete" data-id="${emp.id}">Delete</button>
                    </td>
                </tr>
            `;
            }).join("");
        }

        function showTime() {
            currentTime.textContent = new Date().toLocaleString();
        }

        function getNextId() {
            return employees.length ? Math.max(...employees.map(emp => emp.id)) + 1 : 1001;
        }

        function populateYears() {
            const currentYear = new Date().getFullYear();
            for (let y = currentYear - 5; y <= currentYear + 5; y++) {
                const opt = document.createElement("option");
                opt.value = y;
                opt.textContent = y;
                yearSelect.appendChild(opt);
            }
        }

        function updateDaysAndLop() {
            const days = getDaysInMonth(monthSelect.value, Number(yearSelect.value));
            daysInput.value = days || "";

            const sal = Number(salary.value);
            const leaveCount = Number(leaves.value);
            lop.value = days && !Number.isNaN(sal) && !Number.isNaN(leaveCount) ? calculateLopAmount(sal, days, leaveCount).toFixed(2) : "";
        }

        function resetForm() {
            editingId = null;
            editInfo.classList.add("d-none");
            editIdText.textContent = "";
            addBtn.textContent = "Insert Employee Row";
            monthSelect.value = "";
            yearSelect.value = "";
            daysInput.value = "";
            empName.value = "";
            department.value = "";
            salary.value = "";
            leaves.value = "";
            lop.value = "";
        }

        function fillForm(emp) {
            editingId = emp.id;
            monthSelect.value = emp.month;
            yearSelect.value = emp.year;
            daysInput.value = emp.days;
            empName.value = emp.name;
            department.value = emp.department;
            salary.value = emp.salary;
            leaves.value = emp.leaves;
            lop.value = emp.lop.toFixed(2);
            addBtn.textContent = "Update Employee Row";
            editIdText.textContent = emp.id;
            editInfo.classList.remove("d-none");
            updateDaysAndLop();
        }

        function saveEmployee() {
            const month = monthSelect.value;
            const year = Number(yearSelect.value);
            const days = Number(daysInput.value);
            const name = empName.value.trim();
            const dept = department.value.trim();
            const sal = Number(salary.value);
            const leaveCount = Number(leaves.value);
            const lopAmount = Number(lop.value);

            if (!month || !year || !days || !name || !dept || Number.isNaN(sal) || sal < 0 || Number.isNaN(leaveCount) || leaveCount < 0 || Number.isNaN(lopAmount) || lopAmount < 0) {
                showMessage("Please select month/year and enter valid employee details.", "danger");
                return;
            }

            const record = {
                month,
                year,
                days,
                name,
                department: dept,
                salary: sal,
                leaves: leaveCount,
                lop: lopAmount
            };

            if (editingId === null) {
                record.id = getNextId();
                employees.push(record);
                showMessage("Employee added successfully.", "success");
            } else {
                const index = employees.findIndex(emp => emp.id === editingId);
                if (index !== -1) {
                    employees[index] = { id: editingId, ...record };
                    showMessage("Employee updated successfully.", "success");
                }
            }

            renderTable();
            resetForm();
        }

        function deleteEmployee(id) {
            const index = employees.findIndex(emp => emp.id === id);
            if (index !== -1) {
                employees.splice(index, 1);
                renderTable();
                showMessage("Employee deleted successfully.", "success");
                if (editingId === id) resetForm();
            }
        }

        addBtn.addEventListener("click", saveEmployee);
        btnCancelEdit.addEventListener("click", resetForm);

        [monthSelect, yearSelect, salary, leaves].forEach(input => input.addEventListener("input", updateDaysAndLop));
        [monthSelect, yearSelect, empName, department, salary, leaves].forEach(input => {
            input.addEventListener("keydown", event => {
                if (event.key === "Enter") saveEmployee();
            });
        });

        employeeBody.addEventListener("click", event => {
            const btn = event.target.closest("button[data-id]");
            if (!btn) return;

            const id = Number(btn.dataset.id);
            const action = btn.dataset.action;

            if (action === "edit") {
                const emp = employees.find(item => item.id === id);
                if (emp) fillForm(emp);
            } else if (action === "delete") {
                deleteEmployee(id);
            }
        });

        populateYears();
        updateDaysAndLop();
        renderTable();
        showTime();
        setInterval(showTime, 1000);

        window.addEventListener("load", () => {
            if (window.adsbygoogle) {
                (window.adsbygoogle = window.adsbygoogle || []).push({});
            }
        });
    </script>

  <!-- Required Footer for AdSense -->
    <footer>
        <a href="/privacy.aspx">Privacy Policy</a> | 
        <a href="/terms.html">Terms of Service</a> | 
        <a href="/contact.html">Contact Us</a>


        <p class="mt-2 text-muted">&copy; 2026 Payroll Manager. All rights reserved.</p>
    </footer>
</body>
</html>








