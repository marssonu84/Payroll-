﻿<%@ Page Language="vb" AutoEventWireup="false" CodeBehind="SampleDB.aspx.vb" Inherits="SampleDB.SampleDB" %>

<!DOCTYPE html>

<html  lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<title>MS SQL SAMPLE DATABASE</title>
<link rel="stylesheet" href="font/Audiowide.css" />
<link rel="stylesheet" href="css/style.css"/>
</head>
<body>
<section class="cus-top-section">
	<h2 class="cus-main-heading">MS SQL SAMPLE DATABASE</h2>
</section>
    <form id="form1" runat="server">
<section class="cus-bot-section">
<h2 class="hidden">MS SQL Database</h2>
	<div style="overflow-x:auto;" class="cus-table-outer">
		<div class="cus-btn" >
			<asp:Button ID="btnSampleData" runat="server" Text="Show Sample Data" CssClass="submit" />
		</div>
		<div class="tb-left"> </div>
		<div class="tb-rgt">
        <asp:Label ID="lblMessage" runat="server"></asp:Label>
        <br />
        <asp:GridView ID="GridView1" runat="server">
        </asp:GridView>
        <asp:SqlDataSource ID="sampledataSource" runat="server" ConnectionString="<%$ ConnectionStrings:connection %>" SelectCommand="SELECT * FROM [People]"></asp:SqlDataSource>
		</div>
	</div>
</section>
        </form>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script> 
<script>

$(document).ready(function(){
    $("input.submit").click(function(){
        $("table").toggle();
    });
});
</script> 

</body>
</html>



