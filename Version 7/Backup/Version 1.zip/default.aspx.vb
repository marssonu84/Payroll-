Imports System.Data

Partial Class _Default
    Inherits System.Web.UI.Page

    ' Triggers when the page loads in the browser
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        If Not IsPostBack Then
            InitializeEmployeeTable()
            BindGrid()
        End If
    End Sub

    ' Creates the "Excel Sheet" columns and mock data on first load
    Private Sub InitializeEmployeeTable()
        If Session("EmployeeTable") Is Nothing Then
            Dim dt As New DataTable()
            
            ' Define Excel Columns
            dt.Columns.Add("Employee ID", GetType(Integer))
            dt.Columns.Add("Employee Name", GetType(String))
            dt.Columns.Add("Department", GetType(String))
            dt.Columns.Add("Salary ($)", GetType(Decimal))

            ' Insert Mock Rows
            dt.Rows.Add(101, "John Doe", "Human Resources", 55000.00)
            dt.Rows.Add(102, "Jane Smith", "Engineering", 85000.00)
            dt.Rows.Add(103, "Bob Johnson", "Finance", 68000.00)

            ' Store table in temporary Session state
            Session("EmployeeTable") = dt
        End If
    End Sub

    ' Renders the data table visually onto the web screen
    Private Sub BindGrid()
        Dim dt As DataTable = CType(Session("EmployeeTable"), DataTable)
        gvEmployees.DataSource = dt
        gvEmployees.DataBind()
    End Sub

    ' Code executed when the "Insert Row" button is clicked
    Protected Sub btnAddEmployee_Click(ByVal sender As Object, ByVal e As EventArgs)
        Dim dt As DataTable = CType(Session("EmployeeTable"), DataTable)
        
        ' Generate next Employee ID sequential sequence
        Dim nextId As Integer = 101
        If dt.Rows.Count > 0 Then
            nextId = Convert.ToInt32(dt.Rows(dt.Rows.Count - 1)("Employee ID")) + 1
        End If

        ' Read values from inputs and append new row
        Dim salary As Decimal = 0
        Decimal.TryParse(txtSalary.Text, salary)
        
        dt.Rows.Add(nextId, txtEmpName.Text, txtDepartment.Text, salary)

        ' Update current session memory and refresh UI
        Session("EmployeeTable") = dt
        BindGrid()

        ' Clear form inputs for the next entry
        txtEmpName.Text = ""
        txtDepartment.Text = ""
        txtSalary.Text = ""
        txtEmpName.Focus()
    End Sub
End Class



