<%@ Page Title="Dashboard" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true" CodeFile="Default.aspx.cs" Inherits="PayrollWebApp.Dashboard" %>
<asp:Content ID="c1" ContentPlaceHolderID="TitleContent" runat="server">Dashboard</asp:Content>
<asp:Content ID="c2" ContentPlaceHolderID="MainContent" runat="server">
<h1>Salary Dashboard</h1>
<asp:Panel runat="server" ID="pnlError" Visible="false" CssClass="message error"><asp:Label runat="server" ID="lblError" /></asp:Panel>
<div class="grid4">
<div class="stat">Active Employees<b><asp:Label runat="server" ID="lblEmployees" /></b></div>
<div class="stat">Current Month Gross<b>₹ <asp:Label runat="server" ID="lblGross" /></b></div>
<div class="stat">Current Month Deductions<b>₹ <asp:Label runat="server" ID="lblDeductions" /></b></div>
<div class="stat">Current Month Net Pay<b>₹ <asp:Label runat="server" ID="lblNet" /></b></div>
</div><br/>
<div class="card"><h2>Branch-wise Summary</h2><div class="tablewrap"><asp:GridView runat="server" ID="gvSummary" AutoGenerateColumns="true" CssClass="table" /></div></div>
<div class="card"><h2>Workbook Model Implemented</h2><p class="note">Branch payroll, PF, ESI, PT, salary advances, other deductions, net salary, bank details, monthly summary and loan ledger.</p><p><a href="Setup.aspx">Run database setup</a> if this is the first launch.</p></div>
</asp:Content>
