<%@ Page Title="Loans" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true" CodeFile="Loans.aspx.cs" Inherits="PayrollWebApp.LoansPage" %>
<asp:Content ID="c1" ContentPlaceHolderID="TitleContent" runat="server">Loans</asp:Content>
<asp:Content ID="c2" ContentPlaceHolderID="MainContent" runat="server"><h1>Employee Loan Ledger</h1><asp:Label runat="server" ID="lblMsg" /><div class="card"><div class="formgrid">
<div class="field"><label>Employee</label>

<asp:DropDownList
    runat="server"
    ID="ddlEmployee"
    AutoPostBack="true"
    OnSelectedIndexChanged="ddlEmployee_SelectedIndexChanged" />

</div><div class="field"><label>Date</label><asp:TextBox runat="server" ID="txtDate" TextMode="Date" /></div><div class="field"><label>Opening Balance</label><asp:TextBox runat="server" ID="txtOpening" Text="0" /></div><div class="field"><label>Loan Availed</label><asp:TextBox runat="server" ID="txtAvailed" Text="0" /></div><div class="field"><label>Deduction</label><asp:TextBox runat="server" ID="txtDeduction" Text="0" /></div><div class="field"><label>Remarks</label><asp:TextBox runat="server" ID="txtRemarks" /></div></div><br/><asp:Button runat="server" ID="btnSave" Text="Save Loan Entry" CssClass="btn" OnClick="btnSave_Click" /></div><div class="card"><div class="tablewrap"><asp:GridView runat="server" ID="gvLoans" AutoGenerateColumns="true" /></div></div></asp:Content>

